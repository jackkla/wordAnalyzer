# from flask import Flask, render_template, request, jsonify
# import plotly.express as px
# import plotly.graph_objects as go
# from collections import Counter, defaultdict
# import pandas as pd
# import json
# import random
#
# app = Flask(__name__)
#
# # Custom color scheme
# COLORS = {
#     'background': '#111111',
#     'card': '#1a1a1a',
#     'text': '#ffffff',
#     'accent': '#ff4b1f',
#     'accent_gradient': ['#ff4b1f', '#ff9068'],
#     'highlight': '#ff9068',
#     'visualization': {
#         'primary': '#ff4b1f',
#         'secondary': '#ffff68',
#         'gradient': ['#ff4b1f', '#ff7a46', '#ffff68']
#     }
# }
#
#
# def load_wordlist():
#     with open('wordlist.txt', 'r') as f:
#         return [word.strip().lower() for word in f.readlines()]
#
#
# WORDS = load_wordlist()
#
#
# # [Previous imports and setup remain the same until the analyze_pattern function]
#
# def analyze_pattern(pattern):
#     pattern = pattern.lower()
#     matching_words = [word for word in WORDS if pattern in word]
#
#     if not matching_words:
#         return None
#
#     total_matches = len(matching_words)
#     percentage = (total_matches / len(WORDS)) * 100
#
#     # Position analysis with enhanced data collection
#     positions = []
#     word_positions = defaultdict(list)
#
#     for word in matching_words:
#         pos = word.find(pattern)
#         while pos != -1:
#             rel_pos = pos / len(word)  # Relative position (0-1)
#             positions.append({
#                 'position': pos,
#                 'word_length': len(word),
#                 'relative_position': 'start' if rel_pos < 0.3 else 'end' if rel_pos > 0.7 else 'middle',
#                 'rel_pos': rel_pos
#             })
#             word_positions[word].append(pos)
#             pos = word.find(pattern, pos + 1)
#
#     pos_df = pd.DataFrame(positions)
#
#     # 1. Enhanced Word Length Distribution with correct gradient
#     length_counts = Counter([len(word) for word in matching_words])
#     length_dist = go.Figure(data=go.Bar(
#         x=list(length_counts.keys()),
#         y=list(length_counts.values()),
#         marker=dict(
#             color=list(length_counts.values()),
#             colorscale=[[0, COLORS['visualization']['primary']],
#                         [1, COLORS['visualization']['secondary']]],
#             showscale=False
#         )
#     ))
#     length_dist.update_layout(
#         title='Word Length Distribution',
#         plot_bgcolor=COLORS['card'],
#         paper_bgcolor=COLORS['card'],
#         font=dict(color=COLORS['text']),
#         showlegend=False,
#         xaxis=dict(
#             title='Word Length',
#             gridcolor='rgba(255,255,255,0.1)',
#             zerolinecolor='rgba(255,255,255,0.1)'
#         ),
#         yaxis=dict(
#             title='Number of Words',
#             gridcolor='rgba(255,255,255,0.1)',
#             zerolinecolor='rgba(255,255,255,0.1)'
#         ),
#         margin=dict(t=50, r=20, b=50, l=50)
#     )
#
#     # 2. Enhanced Position Heatmap
#     pos_matrix = pd.pivot_table(
#         pos_df,
#         values='rel_pos',
#         index='word_length',
#         columns='position',
#         aggfunc='count',
#         fill_value=0
#     )
#
#     position_heatmap = go.Figure(data=go.Heatmap(
#         z=pos_matrix.values,
#         x=pos_matrix.columns,
#         y=pos_matrix.index,
#         colorscale=[[0, COLORS['background']],
#                     [0.5, COLORS['visualization']['primary']],
#                     [1, COLORS['visualization']['secondary']]],
#         showscale=True
#     ))
#     position_heatmap.update_layout(
#         title='Pattern Position Heat Map',
#         plot_bgcolor=COLORS['card'],
#         paper_bgcolor=COLORS['card'],
#         font=dict(color=COLORS['text']),
#         xaxis=dict(
#             title='Position in Word',
#             gridcolor='rgba(255,255,255,0.1)',
#         ),
#         yaxis=dict(
#             title='Word Length',
#             gridcolor='rgba(255,255,255,0.1)',
#         ),
#         margin=dict(t=50, r=20, b=50, l=50)
#     )
#
#     # 3. Relative Position Distribution (Area Plot)
#     rel_pos_bins = pd.cut(pos_df['rel_pos'], bins=20)
#     rel_pos_counts = rel_pos_bins.value_counts().sort_index()
#
#     rel_pos_plot = go.Figure(data=go.Scatter(
#         x=[(i.left + i.right) / 2 for i in rel_pos_counts.index],
#         y=rel_pos_counts.values,
#         fill='tozeroy',
#         line=dict(color=COLORS['visualization']['secondary'], width=2),
#         fillcolor=COLORS['visualization']['primary'],
#         mode='lines'
#     ))
#     rel_pos_plot.update_layout(
#         title='Pattern Position Distribution',
#         plot_bgcolor=COLORS['card'],
#         paper_bgcolor=COLORS['card'],
#         font=dict(color=COLORS['text']),
#         showlegend=False,
#         xaxis=dict(
#             title='Relative Position in Word (0=Start, 1=End)',
#             gridcolor='rgba(255,255,255,0.1)',
#             zerolinecolor='rgba(255,255,255,0.1)',
#             range=[0, 1]
#         ),
#         yaxis=dict(
#             title='Frequency',
#             gridcolor='rgba(255,255,255,0.1)',
#             zerolinecolor='rgba(255,255,255,0.1)'
#         ),
#         margin=dict(t=50, r=20, b=50, l=50)
#     )
#
#     # Random sampling with stratification by length
#     length_groups = defaultdict(list)
#     for word in matching_words:
#         length_groups[len(word)].append(word)
#
#     sampled_words = []
#     for length, words in length_groups.items():
#         sample_size = min(2, len(words))
#         sampled_words.extend(random.sample(words, sample_size))
#
#     if len(sampled_words) < 10:
#         additional_needed = 10 - len(sampled_words)
#         remaining_words = [w for w in matching_words if w not in sampled_words]
#         if remaining_words:
#             sampled_words.extend(random.sample(remaining_words, min(additional_needed, len(remaining_words))))
#
#     random.shuffle(sampled_words)  # Shuffle final list for better presentation
#
#     return {
#         'total_matches': total_matches,
#         'percentage': round(percentage, 2),
#         'sample_words': sampled_words,
#         'visualizations': {
#             'length_distribution': json.loads(length_dist.to_json()),
#             'position_heatmap': json.loads(position_heatmap.to_json()),
#             'relative_position': json.loads(rel_pos_plot.to_json())
#         }
#     }
#
#
#
#
# @app.route('/')
# def home():
#     return render_template('index.html', colors=COLORS)
#
#
# @app.route('/analyze', methods=['POST'])
# def analyze():
#     pattern = request.json.get('pattern', '')
#     if not pattern:
#         return jsonify({'error': 'No pattern provided'})
#
#     results = analyze_pattern(pattern)
#     if results is None:
#         return jsonify({'error': 'No matches found'})
#
#     return jsonify(results)
#
#
# if __name__ == '__main__':
#     app.run(debug=True)

from flask import Flask, render_template, request, jsonify
import plotly.express as px
import plotly.graph_objects as go
from collections import Counter, defaultdict
import pandas as pd
import json
from string import ascii_lowercase

app = Flask(__name__)

# Updated color scheme using inferno
COLORS = {
    'background': '#000004',
    'card': '#1b0c41',
    'text': '#ffffff',
    'accent': '#f98c09',
    'accent_gradient': ['#f98c09', '#dc756b'],
    'highlight': '#fcffa4',
    'visualization': {
        'primary': '#721f81',
        'secondary': '#f1605d',
        'gradient': ['#000004', '#721f81', '#f1605d', '#fcffa4']
    }
}


def load_wordlist():
    with open('wordlist.txt', 'r') as f:
        return [word.strip().lower() for word in f.readlines()]


WORDS = load_wordlist()


def analyze_pattern(pattern):
    pattern = pattern.lower()
    matching_words = [word for word in WORDS if pattern in word]

    if not matching_words:
        return None

    total_matches = len(matching_words)
    percentage = (total_matches / len(WORDS)) * 100

    # Position analysis with enhanced data collection
    positions = []
    word_positions = defaultdict(list)
    before_letters = []
    after_letters = []

    for word in matching_words:
        pos = word.find(pattern)
        while pos != -1:
            # Position analysis
            if len(word) > len(pattern):
                rel_pos = pos / (len(word) - len(pattern))  # Adjusted relative position calculation
            else:
                rel_pos = 0  # Or handle it as needed if this situation is meaningful

            positions.append({
                'position': pos,
                'word_length': len(word),
                'relative_position': 'start' if rel_pos < 0.3 else 'end' if rel_pos > 0.7 else 'middle',
                'rel_pos': rel_pos
            })

            # Before/after letter analysis
            if pos > 0:
                before_letters.append(word[pos - 1])
            if pos + len(pattern) < len(word):
                after_letters.append(word[pos + len(pattern)])

            word_positions[word].append(pos)
            pos = word.find(pattern, pos + 1)

    pos_df = pd.DataFrame(positions)

    # 1. Word Length Distribution with inferno colorscale
    length_counts = Counter([len(word) for word in matching_words])
    length_dist = go.Figure(data=go.Bar(
        x=list(length_counts.keys()),
        y=list(length_counts.values()),
        marker=dict(
            color=list(length_counts.values()),
            colorscale='inferno',
            showscale=False
        )
    ))
    length_dist.update_layout(
        title='Word Length Distribution',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color=COLORS['text']),
        showlegend=False,
        xaxis=dict(
            title='Word Length',
            gridcolor='rgba(255,255,255,0.1)',
            zerolinecolor='rgba(255,255,255,0.1)'
        ),
        yaxis=dict(
            title='Number of Words',
            gridcolor='rgba(255,255,255,0.1)',
            zerolinecolor='rgba(255,255,255,0.1)'
        ),
        margin=dict(t=30, r=10, b=50, l=50)
    )

    # 2. Position Heatmap with inferno colorscale
    pos_matrix = pd.pivot_table(
        pos_df,
        values='rel_pos',
        index='word_length',
        columns='position',
        aggfunc='count',
        fill_value=0
    )

    position_heatmap = go.Figure(data=go.Heatmap(
        z=pos_matrix.values,
        x=pos_matrix.columns,
        y=pos_matrix.index,
        colorscale='inferno',
        showscale=True
    ))
    position_heatmap.update_layout(
        title='Pattern Position Heat Map',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color=COLORS['text']),
        xaxis=dict(
            title='Position in Word',
            gridcolor='rgba(255,255,255,0.1)',
        ),
        yaxis=dict(
            title='Word Length',
            gridcolor='rgba(255,255,255,0.1)',
        ),
        margin=dict(t=30, r=10, b=50, l=50)
    )

    # 3. Relative Position Distribution (Area Plot) with adjusted calculation
    bins = [i / 20 for i in range(21)]  # Creates a list [0.0, 0.05, 0.10, ..., 1.0]
    rel_pos_bins = pd.cut(pos_df['rel_pos'], bins=bins, include_lowest=True)
    rel_pos_counts = rel_pos_bins.value_counts().sort_index()

    rel_pos_plot = go.Figure(data=go.Scatter(
        x=[(i.left + i.right) / 2 for i in rel_pos_counts.index],
        y=rel_pos_counts.values,
        fill='tozeroy',
        line=dict(color=COLORS['visualization']['secondary'], width=2),
        fillcolor=COLORS['visualization']['primary'],
        mode='lines'
    ))
    rel_pos_plot.update_layout(
        title='Pattern Position Distribution',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color=COLORS['text']),
        showlegend=False,
        xaxis=dict(
            title='Relative Position in Word (0=Start, 1=End)',
            gridcolor='rgba(255,255,255,0.1)',
            zerolinecolor='rgba(255,255,255,0.1)',
            range=[0, 1]
        ),
        yaxis=dict(
            title='Frequency',
            gridcolor='rgba(255,255,255,0.1)',
            zerolinecolor='rgba(255,255,255,0.1)'
        ),
        margin=dict(t=30, r=10, b=50, l=50)
    )

    # 4. Before/After Letter Analysis
    before_freq = Counter(before_letters)
    after_freq = Counter(after_letters)

    # Ensure all letters are represented
    for letter in ascii_lowercase:
        if letter not in before_freq:
            before_freq[letter] = 0
        if letter not in after_freq:
            after_freq[letter] = 0

    # Sort by alphabet
    before_freq = dict(sorted(before_freq.items()))
    after_freq = dict(sorted(after_freq.items()))

    # Create letter frequency plots
    letter_freq = go.Figure()
    letter_freq.add_trace(go.Bar(
        name='Before Pattern',
        x=list(before_freq.keys()),
        y=list(before_freq.values()),
        marker_color=COLORS['visualization']['primary']
    ))
    letter_freq.add_trace(go.Bar(
        name='After Pattern',
        x=list(after_freq.keys()),
        y=list(after_freq.values()),
        marker_color=COLORS['visualization']['secondary']
    ))
    letter_freq.update_layout(
        title='Letter Frequencies Before/After Pattern',
        barmode='group',
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color=COLORS['text']),
        xaxis=dict(
            title='Letter',
            gridcolor='rgba(255,255,255,0.1)',
            zerolinecolor='rgba(255,255,255,0.1)'
        ),
        yaxis=dict(
            title='Frequency',
            gridcolor='rgba(255,255,255,0.1)',
            zerolinecolor='rgba(255,255,255,0.1)'
        ),
        margin=dict(t=30, r=10, b=50, l=50)
    )

    # Sort matching words by length and alphabetically
    sorted_words = {
        'by_length': sorted(matching_words, key=len),
        'alphabetical': sorted(matching_words)
    }

    return {
        'total_matches': total_matches,
        'percentage': round(percentage, 2),
        'matching_words': sorted_words,
        'visualizations': {
            'length_distribution': json.loads(length_dist.to_json()),
            'position_heatmap': json.loads(position_heatmap.to_json()),
            'relative_position': json.loads(rel_pos_plot.to_json()),
            'letter_frequency': json.loads(letter_freq.to_json())
        }
    }


@app.route('/')
def home():
    return render_template('index.html', colors=COLORS)


@app.route('/analyze', methods=['POST'])
def analyze():
    pattern = request.json.get('pattern', '')
    if not pattern:
        return jsonify({'error': 'No pattern provided'})

    results = analyze_pattern(pattern)
    if results is None:
        return jsonify({'error': 'No matches found'})

    return jsonify(results)


if __name__ == '__main__':
    app.run(debug=True)